class CatatanKeuangan {
  String id;
  String judul;
  String jenis;
  String tanggal;
  int jumlah;
  String deskripsi;

  CatatanKeuangan({
    required this.id,
    required this.judul,
    required this.jenis,
    required this.tanggal,
    required this.jumlah,
    required this.deskripsi,
  });

  factory CatatanKeuangan.fromJson(String id, Map<String, dynamic> json) {
    return CatatanKeuangan(
      id: id,
      judul: json['judul'] ?? '',
      jenis: json['jenis'] ?? '',
      tanggal: json['tanggal'] ?? '',
      jumlah: json['jumlah'] ?? 0,
      deskripsi: json['deskripsi'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "judul": judul,
      "jenis": jenis,
      "tanggal": tanggal,
      "jumlah": jumlah,
      "deskripsi": deskripsi,
    };
  }
}