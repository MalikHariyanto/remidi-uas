import 'package:flutter/material.dart';
import '../Models/Catatan_keuangan.dart';
import '../Services/firebase_service.dart';
import 'Tambah.dart';
import 'Detail.dart';

class BerandaCatatanScreen extends StatefulWidget {
  const BerandaCatatanScreen({super.key});

  @override
  State<BerandaCatatanScreen> createState() => _BerandaCatatanScreenState();
}

class _BerandaCatatanScreenState extends State<BerandaCatatanScreen> {
  List<CatatanKeuangan> daftarCatatan = [];
  int saldo = 0;
  final CatatanKeuanganService _service = CatatanKeuanganService();
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      setState(() => isLoading = true);
      final data = await _service.getCatatan();
      int tempSaldo = 0;

      for (var catatan in data) {
        if (catatan.jenis == "Pemasukan") {
          tempSaldo += catatan.jumlah;
        } else {
          tempSaldo -= catatan.jumlah;
        }
      }

      setState(() {
        daftarCatatan = data;
        saldo = tempSaldo;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Header dengan saldo
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            alignment: Alignment.centerLeft,
            child: RichText(
              text: TextSpan(
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 24, // Increased font size
                ),
                children: [
                  const TextSpan(
                    text: 'Saldo : ',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Inter',
                      letterSpacing: 0.5,
                    ),
                  ),
                  TextSpan(
                    text: 'Rp ${saldo.toString()}',
                    style: const TextStyle(
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Inter',
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // List transaksi
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    itemCount: daftarCatatan.length,
                    padding: const EdgeInsets.all(16),
                    itemBuilder: (context, index) {
                      final catatan = daftarCatatan[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF5B8FB9),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          leading: Image.asset(
                            'assets/nota.png',
                            width: 48,
                            height: 48,
                          ),
                          title: Text(
                            catatan.judul,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                catatan.jenis,
                                style: const TextStyle(color: Colors.white),
                              ),
                              Text(
                                'Tanggal : ${catatan.tanggal}',
                                style: const TextStyle(color: Colors.white),
                              ),
                              Text(
                                'Rp. ${catatan.jumlah}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DetailCatatanScreen(
                                  catatan: catatan,
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF03001C),
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const TambahCatatanScreen(),
            ),
          );
          if (result == true) {
            _loadData();
          }
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}