import 'package:flutter/material.dart';
import '../Models/Catatan_keuangan.dart';

class DetailCatatanScreen extends StatelessWidget {
  final CatatanKeuangan catatan;
  const DetailCatatanScreen({Key? key, required this.catatan}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
          color: Colors.black,
        ),
        title: const Text(
          'Detail',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w900,
            fontFamily: 'Inter',
            letterSpacing: 0.5,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Centered Image
            Center(
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Image.asset(
                  'assets/nota.png',
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 24),
            // Title
            const Text('Title:', 
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF61A3BA),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                catatan.judul,
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            // Jenis
            const Text('Jenis:', 
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF61A3BA),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                catatan.jenis,
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            // Tanggal
            const Text('Tanggal:', 
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF61A3BA),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                catatan.tanggal,
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            // Jumlah
            const Text('Jumlah:', 
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF61A3BA),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Rp. ${catatan.jumlah}',
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            // Deskripsi
            const Text('Deskripsi:', 
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF61A3BA),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                catatan.deskripsi,
                style: const TextStyle(color: Colors.white),
                maxLines: 3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}