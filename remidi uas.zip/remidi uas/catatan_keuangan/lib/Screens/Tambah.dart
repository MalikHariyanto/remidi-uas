import 'package:flutter/material.dart';
import '../Models/Catatan_keuangan.dart';
import '../Services/firebase_service.dart';

class TambahCatatanScreen extends StatefulWidget {
  const TambahCatatanScreen({super.key});

  @override
  State<TambahCatatanScreen> createState() => _TambahCatatanScreenState();
}

class _TambahCatatanScreenState extends State<TambahCatatanScreen> {
  final _formKey = GlobalKey<FormState>();
  final _judulController = TextEditingController();
  final _jumlahController = TextEditingController();
  final _deskripsiController = TextEditingController();
  String? _jenis = 'Pengeluaran';
  DateTime _tanggal = DateTime.now();

  void _simpanData() async {
    if (_formKey.currentState!.validate()) {
      final catatan = CatatanKeuangan(
        id: '',
        judul: _judulController.text.trim(),
        jenis: _jenis!,
        tanggal: "${_tanggal.day} ${_bulanIndo(_tanggal.month)} ${_tanggal.year}",
        jumlah: int.tryParse(_jumlahController.text.trim()) ?? 0,
        deskripsi: _deskripsiController.text.trim(),
      );

      await CatatanKeuanganService().addCatatan(catatan);
      Navigator.pop(context, true);
    }
  }

  String _bulanIndo(int bulan) {
    const namaBulan = [
      '', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    return namaBulan[bulan];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
          color: Colors.black,
        ),
        title: const Text(
          'Tambah Data',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w900,
            fontFamily: 'Inter',
            letterSpacing: 0.5,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Centered Image
              Center(
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Image.asset(
                    'assets/nota.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              // Title Field
              const Text('Title:', style: TextStyle(
                fontSize: 16, 
                fontWeight: FontWeight.w500
              )),
              const SizedBox(height: 8),
              TextFormField(
                controller: _judulController,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xFF61A3BA), // Color from your design
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
                style: const TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 16),
              // Jenis Field
              const Text('Jenis:', style: TextStyle(
                fontSize: 16, 
                fontWeight: FontWeight.w500
              )),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF61A3BA),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButtonFormField<String>(
                  value: _jenis,
                  dropdownColor: const Color(0xFF61A3BA),
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    border: InputBorder.none,
                  ),
                  style: const TextStyle(color: Colors.white),
                  items: const [
                    DropdownMenuItem(value: 'Pengeluaran', child: Text('Pengeluaran')),
                    DropdownMenuItem(value: 'Pemasukan', child: Text('Pemasukan')),
                  ],
                  onChanged: (value) => setState(() => _jenis = value),
                ),
              ),
              const SizedBox(height: 16),
              // Tanggal Field
              const Text('Tanggal:', style: TextStyle(
                fontSize: 16, 
                fontWeight: FontWeight.w500
              )),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFF61A3BA),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: MaterialButton(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: _tanggal,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (picked != null) setState(() => _tanggal = picked);
                  },
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "${_tanggal.day} ${_bulanIndo(_tanggal.month)} ${_tanggal.year}",
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Jumlah Field
              const Text('Jumlah:', style: TextStyle(
                fontSize: 16, 
                fontWeight: FontWeight.w500
              )),
              const SizedBox(height: 8),
              TextFormField(
                controller: _jumlahController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xFF61A3BA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
                style: const TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 16),
              // Deskripsi Field
              const Text('Deskripsi:', style: TextStyle(
                fontSize: 16, 
                fontWeight: FontWeight.w500
              )),
              const SizedBox(height: 8),
              TextFormField(
                controller: _deskripsiController,
                maxLines: 3,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xFF61A3BA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.all(16),
                ),
                style: const TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 24),
              // Simpan Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1B2430),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: _simpanData,
                  child: const Text(
                    'Simpan',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}