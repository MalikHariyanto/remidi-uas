import 'dart:convert';
import 'package:http/http.dart' as http;
import '../Models/Catatan_keuangan.dart';

class CatatanKeuanganService {
  final String baseUrl = 'https://catatankeuangan-ef708-default-rtdb.firebaseio.com/catatankeuangan';

  Future<List<CatatanKeuangan>> getCatatan() async {
    final response = await http.get(Uri.parse('$baseUrl.json'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body) as Map<String, dynamic>?;

      if (data == null) return [];

      return data.entries.map((entry) {
        return CatatanKeuangan.fromJson(entry.key, entry.value);
      }).toList();
    } else {
      throw Exception('Gagal memuat data catatan');
    }
  }

  Future<void> addCatatan(CatatanKeuangan catatan) async {
    final response = await http.post(
      Uri.parse('$baseUrl.json'),
      body: json.encode(catatan.toJson()),
    );

    if (response.statusCode != 200) {
      throw Exception('Gagal menambahkan catatan');
    }
  }

  Future<void> updateCatatan(CatatanKeuangan catatan) async {
    final response = await http.patch(
      Uri.parse('$baseUrl/${catatan.id}.json'),
      body: json.encode(catatan.toJson()),
    );

    if (response.statusCode != 200) {
      throw Exception('Gagal mengupdate catatan');
    }
  }

  Future<void> deleteCatatan(String id) async {
    final response = await http.delete(Uri.parse('$baseUrl/$id.json'));

    if (response.statusCode != 200) {
      throw Exception('Gagal menghapus catatan');
    }
  }
}