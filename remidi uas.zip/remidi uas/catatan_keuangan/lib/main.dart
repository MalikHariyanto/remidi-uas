// Malik Hariyanto
// 230441100067
// PEMBER D
// Kak Putri

import 'package:flutter/material.dart';
import 'Screens/Beranda.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catatan Keuangan',
      theme: ThemeData(
        fontFamily: GoogleFonts.poppins().fontFamily,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5B8FB9), // Warna biru seperti di desain
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF5B8FB9),
          foregroundColor: Colors.black,
        ),
      ),
      home: const BerandaCatatanScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
